# Release manifest — DEMO-1

> POC artifact only. Validate before any deployment.

## Deployment order

| Order | Service | Azure DevOps definition | Owner | Jira stories |
|---:|---|---|---|---|
| 1 | sample-api | ADO pipeline ID TBD | Iliad team to confirm | DEMO-101 |
| 2 | sample-worker | ADO pipeline ID TBD | Iliad team to confirm | DEMO-102 |

## Needs attention

- DEMO-102: missing or unrecognized acceptance criteria
- DEMO-102: unfinished issue (status: In Progress)
- DEMO-103: unknown service tag missing-service

## Summary

- Stories scanned: 3
- Services mapped: 2
- Warnings: 3
