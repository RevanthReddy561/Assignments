# Release Manifest Generator — Initial POC

**This package contains fictional sample data, not validated Iliad release information.**

Requires Python 3.9+; no external Python dependencies.

## Test offline

Run from this folder:

```sh
python release_manifest.py --issues sample_issues.json --registry services_registry.json --release DEMO-1 --out output
```

Inspect `output/release-manifest.md` and `output/release-manifest.json`.

## Jira read-only mode

Confirm authentication method and service custom field with your Jira admin. The sample uses Jira Server/Data Center REST API v2 and Basic auth, which **may not be enabled by your organization**.

Set `JIRA_USER` and `JIRA_API_TOKEN` as environment variables (never commit credentials); then:

```sh
python release_manifest.py --jira-url https://YOUR-JIRA-HOST --project YOURPROJECT --release YOUR_FIX_VERSION --registry services_registry.json --out output
```

For a real multi-select field, append `--tag-field customfield_12345`. For explicit acceptance criteria, append `--acceptance-field customfield_67890`.

## Work required before real POC sign-off

- Confirm Jira URL/authentication method and rights to search target projects/releases.
- Verify Jira field IDs, label format, definition of Done statuses and acceptance criteria conventions.
- Replace fictional services and ordering with dev-team-confirmed Iliad registry, ADO definitions, and owners.
- Compare output with an actual recently deployed release and explain differences.
- Validate edge cases and improve issue metadata checks (especially rich-text acceptance criteria).
- Assess Go/AI and M365 separately. This script does not deploy anything.

## Caveats

- The pipeline field contains descriptive registry identifiers and is not validated against Azure DevOps.
- Status validation uses `Done`, `Closed`, or `Resolved` defaults; tailor to your Jira workflow.
- Unknown services are shown in `Needs attention` but intentionally not added to deployment order.
- Registry `order` must be confirmed by application teams.
- Jira integration requires connectivity and a compatible auth scheme; errors are not hidden.
