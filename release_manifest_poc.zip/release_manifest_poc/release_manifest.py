#!/usr/bin/env python3
"""Release manifest POC: offline issues JSON or read-only Jira REST API.
Python 3.9+, standard library only. No deploy operations.
"""
import argparse
import base64
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def load_json(path):
    with open(path, encoding='utf-8') as stream:
        return json.load(stream)


def jira_issues(base_url, project, version):
    user, token = os.getenv('JIRA_USER'), os.getenv('JIRA_API_TOKEN')
    if not user or not token:
        raise ValueError('Set JIRA_USER and JIRA_API_TOKEN for Jira mode (read-only credentials).')
    jql = f'project = "{project}" AND fixVersion = "{version}" ORDER BY key ASC'
    auth = base64.b64encode(f'{user}:{token}'.encode()).decode()
    issues, start = [], 0
    while True:
        params = urlencode({'jql': jql, 'startAt': start, 'maxResults': 100,
                            'fields': 'summary,status,labels,fixVersions,description'})
        url = base_url.rstrip('/') + '/rest/api/2/search?' + params
        request = Request(url, headers={'Authorization': f'Basic {auth}', 'Accept':'application/json'})
        with urlopen(request, timeout=30) as response:
            result = json.load(response)
        batch = result.get('issues', [])
        issues.extend(batch)
        start += len(batch)
        if not batch or start >= result.get('total', start):
            break
    return issues


def get_services(fields, tag_field):
    if tag_field:
        items = fields.get(tag_field) or []
        if not isinstance(items, list):
            items = [items]
        return sorted(set((v.get('value') or v.get('name') or '') if isinstance(v, dict) else str(v) for v in items) - {''})
    return sorted(set(label[4:] for label in fields.get('labels', []) if label.startswith('svc-')))


def get_acceptance(fields, acceptance_field):
    if acceptance_field:
        return bool(fields.get(acceptance_field))
    # Fallback is conservative: ADO/Jira requirements vary by Jira installation.
    desc = fields.get('description') or ''
    if isinstance(desc, dict):
        desc = json.dumps(desc)
    return bool(re.search(r'acceptance criteria\s*:\s*\S', str(desc), re.I))


def generate(issues, registry, release, tag_field='', acceptance_field=''):
    services = registry['services']
    grouped, warnings = defaultdict(list), []
    for issue in issues:
        fields = issue.get('fields', issue)
        key = issue.get('key', 'UNKNOWN')
        names = get_services(fields, tag_field)
        if not names:
            warnings.append(f'{key}: missing affected-service tags')
        for name in names:
            if name not in services:
                warnings.append(f'{key}: unknown service tag {name}')
            else:
                grouped[name].append(key)
        status = fields.get('status', '')
        if isinstance(status, dict):
            status = status.get('name', '')
        if str(status).strip().lower() not in {'done', 'closed', 'resolved'}:
            warnings.append(f'{key}: unfinished issue (status: {status or "missing"})')
        if not get_acceptance(fields, acceptance_field):
            warnings.append(f'{key}: missing or unrecognized acceptance criteria')
    deployments = []
    for name in sorted(grouped, key=lambda n: (services[n].get('order', 9999), n)):
        svc = services[name]
        deployments.append({'service': name, 'order': svc.get('order'),
                            'pipeline': svc.get('pipeline', 'TBD'),
                            'owner': svc.get('owner', 'TBD'),
                            'stories': sorted(grouped[name])})
    return {'release': release, 'generated_utc': datetime.now(timezone.utc).isoformat(),
            'deployments': deployments, 'needs_attention': sorted(set(warnings)),
            'summary': {'issues': len(issues), 'services': len(deployments),
                        'warnings': len(set(warnings))}}


def markdown(data):
    lines = [f'# Release manifest — {data["release"]}', '',
             '> POC artifact only. Validate before any deployment.', '',
             '## Deployment order', '',
             '| Order | Service | Azure DevOps definition | Owner | Jira stories |',
             '|---:|---|---|---|---|']
    for item in data['deployments']:
        vals = [str(item['order'] if item['order'] is not None else 'TBD'),
                item['service'], item['pipeline'], item['owner'], ', '.join(item['stories'])]
        lines.append('| ' + ' | '.join(str(v).replace('|','\\|').replace('\n',' ') for v in vals) + ' |')
    if not data['deployments']:
        lines.append('| — | No mapped services | — | — | — |')
    lines.extend(['', '## Needs attention', ''])
    lines.extend(f'- {warning}' for warning in data['needs_attention'])
    if not data['needs_attention']:
        lines.append('- No issues detected by POC checks; manual release approval is still required.')
    lines.extend(['', '## Summary', '',
                  f'- Stories scanned: {data["summary"]["issues"]}',
                  f'- Services mapped: {data["summary"]["services"]}',
                  f'- Warnings: {data["summary"]["warnings"]}', ''])
    return '\n'.join(lines)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--registry', default='services_registry.json')
    p.add_argument('--issues', help='Offline Jira-shaped JSON array')
    p.add_argument('--jira-url', help='Base Jira URL; uses read-only API')
    p.add_argument('--project', help='Jira project key, Jira mode')
    p.add_argument('--release', required=True, help='Fix version/release name')
    p.add_argument('--tag-field', default='', help='Jira custom field ID for affected services, e.g. customfield_12345')
    p.add_argument('--acceptance-field', default='', help='Jira custom field ID for acceptance criteria')
    p.add_argument('--out', default='output')
    args = p.parse_args()
    if bool(args.issues) == bool(args.jira_url):
        p.error('Choose exactly one of --issues or --jira-url')
    if args.jira_url and not args.project:
        p.error('--project is required in Jira mode')
    registry = load_json(args.registry)
    issues = load_json(args.issues) if args.issues else jira_issues(args.jira_url, args.project, args.release)
    if isinstance(issues, dict):
        issues = issues.get('issues', [])
    data = generate(issues, registry, args.release, args.tag_field, args.acceptance_field)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'release-manifest.json').write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
    (out / 'release-manifest.md').write_text(markdown(data), encoding='utf-8')
    print(f'Manifest written: {out}; {data["summary"]}')
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as exc:
        sys.exit(f'Error: {exc}')
